# Code Citations

## License: unknown

https://github.com/adhy06/absensigps/tree/814a3ac0e498b37f59d5b7f7081fa7115e3b7c85/resources/views/absensi/create.blade%20copy%202.php

```
->
<link
  rel="stylesheet"
  href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
/>
<script src="https://unpkg.com/leaflet@1.9.
```

## License: unknown

https://github.com/samanbey/summerschool-leaflet/tree/c06b0869a2afe528b71cea5f9f27636e7c80343a/l1.html

```
rel="stylesheet"
  href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
/>
<script src="https://unpkg.com/leaflet@1.9.4/dist/
```
